AnimalTrack Zebra: YOLO/Farneback/EKF tracking
Ground truth available: True.
When missing, reference-based metrics are NaN, not zero or pseudo-label values.
tracking_summary.csv: aggregate association and localization metrics.
per_frame_metrics.csv: thresholded IoU matching, per frame.
fusion_trajectories.csv: predicted track IDs and boxes.
processing_times_and_motion.csv: end-to-end timing and flow magnitude.
global_IDF1_proxy is not the official IDF1 implementation.
target_state_diagnostics.csv includes separate prior, flow, and posterior observations.
target_error_summary.csv gives paired, matched-only RMSE; coverage is reported.
Sparse LK is a standalone diagnostic, not part of the Farneback-EKF inference path.
sparse_lk_feature_diagnostics.csv records feature counts and replenishment events.
Simulated detection dropout is disabled unless configured before tracking.
